<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Selamat Datang di Halaman Mahasiswa</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Blank Page</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Title</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>
        <div class="card-body">
          <h1>Mahasiswa</h1><br>
          <div class="container">
            <table class="table table-striped text-center ">
              <thead>
                  <th>No</th>
                  <th>NIM</th>
                  <th>Nama Mahasiswa</th>
                  <th>Gender</th>
                  <th>Tempat Lahir</th>
                  <th>Tanggal Lahir</th>
                  <th>IPK</th>
                  <th>Kode Prodi</th>
                  <th>Action</th>
              </thead>
              <tbody>
                  <?php
                      $nomor = 1;
                      foreach($list_mahasiswa as $row){
                  ?>
                  <tr>
                      <td><?=$nomor?></td>
                      <td><?=$row->nim?></td>
                      <td><?=$row->nama?></td>
                      <td><?=$row->gender?></td>
                      <td><?=$row->tmp_lahir?></td>
                      <td><?=$row->tgl_lahir?></td>
                      <td><?=$row->ipk?></td>
                      <td><?=$row->prodi_kode?></td>
                      <td>
                        <a href="view?id=<?=$row->nim?>" style="text-decoration: none">view</a> |
                        <a href="edit?id=<?=$row->nim?>" style="text-decoration: none">Edit</a> |
                        <a href="delete?id=<?=$row->nim?>" style="text-decoration: none" onclick="if(!confirm('Anda yakin hapus mahasiswa NIM <?=$row->nim?>?')){return false}">Delete</a>
                      </td>
                  </tr>
                  <?php
                      $nomor++;
                      }
                  ?>
              </tbody>
            </table>
          </br>
            <?php echo form_open('mahasiswa/create')?>
              <button type="submit" class="btn btn-success">Tambah Mahasiswa</button>
            <?php echo form_close()?>
          </div>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          Footer
        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
